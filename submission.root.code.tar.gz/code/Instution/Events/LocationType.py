from enum import Enum

'''
    LocatioType Enum
'''
class LocationType(Enum):
    ONLINE = 0
    ONSITE = 1